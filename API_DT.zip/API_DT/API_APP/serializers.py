from rest_framework import serializers
from django.contrib.auth.models import User
from .models import company

class CompanySerializer(serializers.ModelSerializer):
    attendees = serializers.PrimaryKeyRelatedField(queryset=User.objects.all(), many=True, required=False)
    
    company_uid=serializers.ReadOnlyField()
    class Meta:
        model=company
        fields="__all__"
    
    def create(self, validated_data):
        attendees_data=validated_data.pop('attendees',[])
        Company=company.objects.create(**validated_data)
        Company.attendees.set(attendees_data)
        return Company
    
    def update(self,instance, validated_data):
        attendees_data=validated_data.pop('attendees',[])
        instance=super().update(instance, validated_data)
        instance.attendees.set(attendees_data)
        return instance