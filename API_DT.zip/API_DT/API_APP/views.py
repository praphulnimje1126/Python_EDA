from django.shortcuts import render
from rest_framework import viewsets
from API_APP.models import company
from API_APP.serializers import CompanySerializer
from rest_framework.decorators import action
from rest_framework.response import Response

# Create your views here.

from django. http import JsonResponse
def home(request):
    list=['Praphul','Sandeep','Akash','Vikas']
    return JsonResponse(list,safe=False)

class company_view(viewsets.ModelViewSet):
    queryset=company.objects.all()
    serializer_class=CompanySerializer

    @action(detail=True,methods=['GET'])
    def attendees(self,request,pk=None):
        event =self.get_object()
        attendee_uid=list(event.attendees.values_list('uid',flat=True))
        return Response(attendee_uid)
    
    def update(self, request, *args, **kwargs):
        partial= kwargs.pop('partial',False)
        instance=self.get_object()

        # handle attendees
        attendee_uids=request.data.get('attendees',[])
        instance.attendees.set(attendee_uids)
        serializer=self.get_serializer(instance,data=request.data,partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)

        if getattr(instance, '_prefetched_object_cache',None):
            instance._prefetched_object_cache={}
        return Response(serializer.data)
        
