from django.contrib import admin
from .models import company

# Register your models here.
class CompanyAdmin(admin.ModelAdmin):
    list_display=['type','uid','name','tagline','schedule','description','files_image','category','sub_category','rigor_rank']

admin.site.register(company,CompanyAdmin)