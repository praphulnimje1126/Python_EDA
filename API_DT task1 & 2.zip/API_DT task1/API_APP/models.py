from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class company(models.Model):
    type = models.CharField(max_length=20,choices=(('IT','IT'),
                                                   ('Non-IT','Non-IT')))  
    uid = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100) 
    tagline = models.CharField(max_length=200)
    schedule = models.DateTimeField()
    description = models.TextField()
    files_image = models.ImageField(upload_to='event_images/', null=True, blank=True)
    moderator = models.CharField(max_length=50)
    category = models.CharField(max_length=50) 
    sub_category = models.CharField(max_length=50) 
    rigor_rank = models.IntegerField()
    attendees = models.ManyToManyField(User, related_name='attended_events')  

    def __str__(self):
        return self.name , self.uid
