
from django.urls import path,include
from API_APP.views import company_view
from rest_framework import routers

router=routers.DefaultRouter()
router.register(r'companies',company_view)

urlpatterns = [
    path('',include(router.urls))
]